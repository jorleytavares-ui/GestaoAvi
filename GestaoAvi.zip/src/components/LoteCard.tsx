// src/components/LoteCard.tsx
import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Wheat, TrendingUp } from 'lucide-react-native';
import { COLORS } from '../theme/colors';
import { StatCard } from './StatCard';
import { fmt } from '../utils/calculations';

interface LoteCardProps {
  numero: string;
  linhagem: string;
  nomesGalpoes: string;
  status: 'ativo' | 'encerrado';
  idadeDias: number;
  viabilidade: number;
  avesVivas: number;
  quantidadeAlojadaTotal: number;
  numGalpoes: number;
  liberado?: boolean;
  ownerId?: string | null;
  ownerNome?: string | null;
  empresaNome?: string | null;
  numeroGranja?: string | number | null;
  racaoAcumuladaKg?: number | null;       // 👈 novo
  conversaoAlimentar?: number | null;     // 👈 novo
  gpd?: number | null;                    // 👈 novo
  onPress: () => void;
}

export function LoteCard({
  numero,
  linhagem,
  nomesGalpoes,
  status,
  idadeDias,
  viabilidade,
  avesVivas,
  quantidadeAlojadaTotal,
  numGalpoes,
  liberado,
  ownerId,
  ownerNome,
  empresaNome,
  numeroGranja,
  racaoAcumuladaKg,
  conversaoAlimentar,
  gpd,
  onPress,
}: LoteCardProps) {
  const ativo = status === 'ativo';

  return (
    <Pressable
      onPress={onPress}
      style={{
        backgroundColor: COLORS.surface,
        borderWidth: 1,
        borderColor: COLORS.line,
        borderRadius: 14,
        padding: 16,
        marginTop: 16,
        gap: 10,
      }}
    >
      {/* Cabeçalho */}
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <View>
          <Text style={{ fontSize: 16.8, fontWeight: '700', color: COLORS.ink }}>
            Lote {numero}
          </Text>

          {empresaNome && (
            <Text style={{ fontSize: 12, color: COLORS.inkSoft, marginTop: 2 }}>
              Integrado:{' '}
              <Text style={{ fontWeight: '600', color: COLORS.ink }}>{empresaNome}</Text>
            </Text>
          )}

          <Text style={{ fontSize: 12.8, color: COLORS.inkSoft, marginTop: 2 }}>
            {nomesGalpoes} · {linhagem}
          </Text>
        </View>

        {/* Selo de status */}
        <View
          style={{
            alignSelf: 'flex-start',
            borderWidth: 2,
            borderColor: ativo ? COLORS.primary : COLORS.inkSoft,
            borderRadius: 6,
            paddingHorizontal: 9,
            paddingVertical: 3,
            transform: [{ rotate: '-4deg' }],
          }}
        >
          <Text
            style={{
              fontSize: 10.4,
              fontWeight: '700',
              letterSpacing: 1,
              textTransform: 'uppercase',
              color: ativo ? COLORS.primary : COLORS.inkSoft,
            }}
          >
            {ativo ? 'Ativo' : 'Encerrado'}
          </Text>
        </View>
      </View>

      {/* Responsável pelo lote */}
      <Text style={{ fontSize: 12.5, color: COLORS.inkSoft, marginTop: -4 }}>
        Resp:{' '}
        <Text style={{ fontWeight: '600', color: COLORS.ink }}>
          {liberado || !ownerId ? 'Lote livre' : ownerNome || 'Usuário não identificado'}
        </Text>
      </Text>

      {/* Nº da granja */}
      {numeroGranja !== undefined && numeroGranja !== null && (
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 }}>
          <Text style={{ fontSize: 12.5, color: COLORS.inkSoft }}>Nº da granja</Text>
          <Text style={{ fontSize: 12.5, fontWeight: '600', color: COLORS.ink }}>{numeroGranja}</Text>
        </View>
      )}

      {/* Linha de indicadores */}
      <View
        style={{
          flexDirection: 'row',
          gap: 16,
          paddingTop: 8,
          borderTopWidth: 1,
          borderTopColor: COLORS.line,
          borderStyle: 'dashed',
        }}
      >
        <Text style={{ fontSize: 12.8 }}>
          <Text style={{ color: COLORS.inkSoft }}>Idade </Text>
          <Text style={{ color: COLORS.ink }}>{idadeDias}d</Text>
        </Text>

        <Text style={{ fontSize: 12.8 }}>
          <Text style={{ color: COLORS.inkSoft }}>Viab. </Text>
          <Text style={{ color: COLORS.ink }}>{viabilidade.toFixed(1)}%</Text>
        </Text>

        <Text style={{ fontSize: 12.8 }}>
          <Text style={{ color: COLORS.inkSoft }}>Aves </Text>
          <Text style={{ color: COLORS.ink }}>
            {avesVivas}/{quantidadeAlojadaTotal}
          </Text>
        </Text>
      </View>

      {/* 👇 Mini StatCards (somente na Home) */}
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 2 }}>
        <View style={{ flex: 1 }}>
          <StatCard icon={Wheat} label="Ração ac." value={fmt(racaoAcumuladaKg ?? null, 0)} unit="kg" />
        </View>
        <View style={{ flex: 1 }}>
          <StatCard
            icon={TrendingUp}
            label="Conversão"
            value={conversaoAlimentar != null ? fmt(conversaoAlimentar, 3) : '—'}
            unit=""
          />
        </View>
        <View style={{ flex: 1 }}>
          <StatCard
            icon={TrendingUp}
            label="GPD"
            value={gpd != null ? fmt(gpd, 1) : '—'}
            unit="g/dia"
          />
        </View>
      </View>

      {numGalpoes > 1 && (
        <Text style={{ fontSize: 11.5, color: COLORS.inkSoft }}>
          {numGalpoes} galpões neste lote
        </Text>
      )}
    </Pressable>
  );
}
