// AuthContext.tsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import { createClient, Session, User } from '@supabase/supabase-js';
import { estaConectado, comTimeout } from '../utils/connectivity';
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from '../lib/supabase';
import {
   salvarCredencialLocal,
   validarCredencialLocal,
   buscarEmailLocalPorCpf,
   atualizarTokensLocal,
   removerCredencialLocal,
 } from './authVault';
import { salvarPerfilCache, getPerfilCache } from '../storage/perfilCache';
import { sincronizarRelogioServidor } from '../services/serverTime';
import { baixarLotesDoServidor, baixarFaixaConforto } from '../storage/sync';
import { PAPEL_ID } from '../constants/papeis';
import * as Crypto from 'expo-crypto';
import { onSessaoInvalida, emitSessaoInvalida } from './authSessionEvents';
import NetInfo from '@react-native-community/netinfo';
import { getModoSync, getHorarioSync } from '../storage/syncPrefs';
import { onSyncStatusChange } from '../storage/syncStatusEmitter';
import { deveExibirOnline } from '../utils/statusConectividadeDisplay';
import { Alert } from 'react-native';

type OpcaoEmpresa = { email: string; empresaId: string; empresaNome: string };

type AuthContextData = {
  session: Session | null;
  user: User | null;
  userId: string | null;
  offline: boolean;
  carregandoSessao: boolean;
  precisaRedefinirSenha: boolean;
  empresaId: string | null;
  empresaTipo: string | null;
  signIn: (email: string, senha: string) => Promise<{ error?: string }>;
  signInComCpf: (
    cpf: string,
    senha: string
  ) => Promise<{ error?: string; opcoes?: OpcaoEmpresa[] }>;
  signUp: (params: {
  senha: string;
  nomeEmpresa: string;
  nomeUsuario: string;
  cpf: string;
  emailContato?: string;
  tipoPessoa: 'Fisica' | 'Juridica';
  cpfCnpj: string;
  responsavel: string;
  telefone: string;
  paisId: number;
  estadoId: number;
  cidade: string;
  tipoEmpresa: string;
  codigoIntegracao: string | null;
  codigoParceiro: string | null; 
}) => Promise<{ error?: string }>;

  signOut: () => Promise<void>;
  atualizarSenhaPropria: (novaSenha: string) => Promise<{ error?: string }>;
};

const AuthContext = createContext<AuthContextData>({} as AuthContextData);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [offline, setOffline] = useState(false);
  const [carregandoSessao, setCarregandoSessao] = useState(true);
  const [precisaRedefinirSenha, setPrecisaRedefinirSenha] = useState(false);
  const [empresaId, setEmpresaId] = useState<string | null>(null);
  const [empresaTipo, setEmpresaTipo] = useState<string | null>(null);
  const [netConectado, setNetConectado] = useState(false);
  const [sincronizandoAgora, setSincronizandoAgora] = useState(false);
  const sessionRef = React.useRef<Session | null>(null);
  const refreshEmAndamento = React.useRef(false);

function estaDentroDaJanelaAgendada(horario: string | null): boolean {
  if (!horario) return false;
  const [hh, mm] = horario.split(':').map(Number);
  const agora = new Date();
  const inicioJanela = new Date();
  inicioJanela.setHours(hh, mm, 0, 0);
  const fimJanela = new Date(inicioJanela.getTime() + 5 * 60 * 1000); // janela de 5 min
  return agora >= inicioJanela && agora <= fimJanela;
}

useEffect(() => {
  // Só faz sentido recalcular o badge se houver sessão ativa.
  if (!session) return;

  async function recalcularOffline() {
    const modo = await getModoSync();
    const horario = modo === 'horario' ? await getHorarioSync() : null;

    const online = deveExibirOnline({
      modo,
      netConectado,
      sincronizandoAgora,
      dentroDaJanelaAgendada: estaDentroDaJanelaAgendada(horario),
    });

    setOffline(!online);
  }

  recalcularOffline();

  const unsubscribeNet = NetInfo.addEventListener((state) => {
    if (!state.isConnected) {
       setNetConectado(false);
       return;
     }
     // state.isConnected só indica link de rede ativo (rádio/Wi-Fi associado),
     // não garante internet real. Reavaliamos com o teste de conectividade
     // real (fetch de health-check) antes de assumir que está online.
     estaConectado().then(setNetConectado);
  });

  const unsubscribeSync = onSyncStatusChange((emAndamento) => {
    setSincronizandoAgora(emAndamento);
  });

  // Reavalia a cada minuto (cobre a janela do modo 'horario' abrir/fechar).
  const intervalId = setInterval(recalcularOffline, 60 * 1000);

  return () => {
    unsubscribeNet();
    unsubscribeSync();
    clearInterval(intervalId);
  };
}, [session]);




useEffect(() => {
  sessionRef.current = session;
}, [session]);

useEffect(() => {
  if (!netConectado) return;
  const sessaoAtual = session;
  if (!sessaoAtual) return;
  if (refreshEmAndamento.current) return; // evita chamada duplicada/concorrente

  refreshEmAndamento.current = true;

  (async () => {
    try {
      // Primeiro verifica se o client JÁ tem sessão válida internamente
      // (ex.: renovada pelo autoRefreshToken). Se tiver, não precisa fazer nada.
      const { data: clientSession } = await supabase.auth.getSession();
      if (clientSession.session) {
        setSession(clientSession.session);
        setOffline(false);
        return;
      }

      // Client sem sessão interna (típico de login offline onde o setSession
      // falhou silenciosamente por falta de rede). Precisa re-hidratar.
      const { data, error } = await supabase.auth.refreshSession({
        refresh_token: sessaoAtual.refresh_token,
      });

      if (error) {
        console.log('refreshSession ao reconectar falhou:', error.message);
        // Token de refresh morto/rotacionado no servidor. Manter a sessão
         // "zumbi" local só adia o problema — toda chamada autenticada vai
         // continuar falhando. Limpa o vault local (para não reutilizar
         // esse token morto num próximo login offline) e força o usuário
         // de volta à tela de login para reautenticar online.
         if (sessaoAtual.user?.email) {
           await removerCredencialLocal(sessaoAtual.user.email).catch((e) =>
             console.log('Falha ao limpar credencial local morta:', e)
           );
         }
         emitSessaoInvalida();
        return;
      }

      if (data.session) {
        setSession(data.session);
        setOffline(false);
        if (data.session.user.email) {
          await atualizarTokensLocal(
            data.session.user.email,
            data.session.access_token,
            data.session.refresh_token
          );
        }
      }
    } finally {
      refreshEmAndamento.current = false;
    }
  })();
}, [netConectado, session]);

  async function verificarNecessidadeRedefinicao(userId: string, tempClient?: any) {
    const client = tempClient ?? supabase;
    const { data } = await client
      .from('perfis')
      .select('precisa_redefinir_senha')
      .eq('id', userId)
      .maybeSingle();

    setPrecisaRedefinirSenha(!!data?.precisa_redefinir_senha);
  }

  useEffect(() => {
    async function verificarSessao() {
  const { data: sessionData } = await supabase.auth.getSession();

  if (sessionData.session) {
    const conectado = await estaConectado();     // ✅ usa o novo helper

    if (conectado) {                             // ✅ usa o novo helper
      const { data: userData, error } = await supabase.auth.getUser();
      if (error || !userData.user) {
        await supabase.auth.signOut();
        setSession(null);
      } else {
        setSession(sessionData.session);
        setOffline(false);
        const perfilCache = await getPerfilCache(userData.user.id);
        setPrecisaRedefinirSenha(!!perfilCache?.precisaRedefinirSenha);
        setEmpresaId(perfilCache?.empresaId ?? null);
        setEmpresaTipo(perfilCache?.empresaTipo ?? null);
        await verificarNecessidadeRedefinicao(userData.user.id);
      }
    } else {
      setSession(sessionData.session);
      setOffline(true);
      const perfilCache = await getPerfilCache(sessionData.session.user.id);
      setPrecisaRedefinirSenha(!!perfilCache?.precisaRedefinirSenha);
      setEmpresaId(perfilCache?.empresaId ?? null);
      setEmpresaTipo(perfilCache?.empresaTipo ?? null);
    }
  } else {
    setSession(null);
  }
  setCarregandoSessao(false);
}


    verificarSessao();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);

       // O client renova o token automaticamente em background (autoRefreshToken).
 // Sem gravar essa renovação no vault, o token salvo localmente fica
 // desatualizado — e um login offline subsequente usaria um refresh_token
 // já invalidado no servidor, causando logout na próxima reconexão.
 if (_event === 'TOKEN_REFRESHED' && newSession?.user?.email) {
   atualizarTokensLocal(
     newSession.user.email,
     newSession.access_token,
     newSession.refresh_token
   ).catch((e) =>
     console.log('Falha ao persistir token renovado no vault:', e)
   );
 }
    });

    // ✅ Escuta o evento global de "sessão inválida" (token de refresh expirado
    // ou revogado, detectado em lib/supabase.ts ou storage/sync.ts). Sem isso,
    // o app podia ficar com uma sessão "zumbi": parecia logado, mas todas as
    // chamadas ao backend falhavam silenciosamente, sem nunca levar o usuário
    // de volta para a tela de login.
    const unsubscribeSessaoInvalida = onSessaoInvalida(() => {
      setSession(null);
      setOffline(false);
      setPrecisaRedefinirSenha(false);
      setEmpresaId(null);
      setEmpresaTipo(null);
      setCarregandoSessao(false);
    });

    return () => {
      listener.subscription.unsubscribe();
      unsubscribeSessaoInvalida();
    };
  }, []);

  async function criarEmpresaPerfilELicenca(
    tempClient: any,
    userId: string,
    nomeUsuario: string,
    nomeEmpresa: string
  ) {
    const { data: empresaData, error: empresaError } = await tempClient
      .from('empresas')
      .insert({ nome: nomeEmpresa, owner_id: userId })
      .select()
      .single();

    if (empresaError || !empresaData) {
      return { error: empresaError?.message ?? 'Erro ao criar empresa.' };
    }

    const { error: perfilError } = await tempClient.from('perfis').insert({
      id: userId,
      nome: nomeUsuario,
      empresa_id: empresaData.id,
      papel_id: PAPEL_ID.ADMIN,
    });

    if (perfilError) {
      return { error: perfilError.message };
    }

    const { error: licencaError } = await tempClient.from('licencas').insert({
      empresa_id: empresaData.id,
      status: 'trial',
      limite_lotes: 3,
      lotes_gerados: 0,
      trial_inicio: new Date().toISOString().slice(0, 10),
      trial_dias: 14,
    });

    if (licencaError) {
      return { error: licencaError.message };
    }

    return { empresaId: empresaData.id, empresaTipo: (empresaData as any)?.tipo ?? null };
  }

  async function buscarEmailPorCpf(
    cpf: string
  ): Promise<{ email?: string; opcoes?: OpcaoEmpresa[]; error?: string }> {
    const cpfLimpo = cpf.replace(/\D/g, '');

    const { data, error } = await supabase.functions.invoke('buscar-email-por-cpf', {
      body: { cpf: cpfLimpo },
    });

    if (error) {
     console.log('Erro real ao invocar buscar-email-por-cpf:', error);
     return { error: 'Erro ao buscar CPF. Verifique sua conexão.' };
    }
    if (data?.error) return { error: data.error };

    if (data?.opcoes) return { opcoes: data.opcoes };
    return { email: data.email };
  }

  async function signInOnline(email: string, senha: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password: senha,
    });

    if (error) return { error: error.message };
    if (!data.user || !data.session) {
      return { error: 'Não foi possível autenticar o usuário.' };
    }

    const userId = data.user.id;
    const token = data.session.access_token;

    const tempClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: perfilExistente, error: perfilCheckError } = await tempClient
      .from('perfis')
      .select('id, nome, empresa_id, papel_id, cpf, precisa_redefinir_senha')
      .eq('id', userId)
      .maybeSingle();

    if (perfilCheckError) return { error: perfilCheckError.message };

    let empresaIdLocal: string | null = perfilExistente?.empresa_id ?? null;
    let nome = perfilExistente?.nome ?? email.split('@')[0];
    let papelId = perfilExistente?.papel_id ?? PAPEL_ID.ADMIN;
    const cpf: string | undefined = (perfilExistente as any)?.cpf ?? undefined;
    let empresaTipoLocal: string | null = null;

    if (perfilExistente) {
      setPrecisaRedefinirSenha(!!(perfilExistente as any)?.precisa_redefinir_senha);
    }

    if (!perfilExistente) {
      const metadata = data.user.user_metadata ?? {};
      const nomeUsuario = metadata.nome_usuario ?? email.split('@')[0];
      const nomeEmpresa = metadata.nome_empresa ?? `Empresa de ${email.split('@')[0]}`;

      const resultado = await criarEmpresaPerfilELicenca(
        tempClient,
        userId,
        nomeUsuario,
        nomeEmpresa
      );

      if (resultado.error) return { error: resultado.error };
      empresaIdLocal = resultado.empresaId ?? null;
      empresaTipoLocal = resultado.empresaTipo ?? null;
      nome = nomeUsuario;
      papelId = PAPEL_ID.ADMIN;
      setPrecisaRedefinirSenha(false);
    }

    let ownerId = userId;
    if (empresaIdLocal) {
      // ✅ Busca owner_id e tipo da empresa numa única query
      const { data: empresa } = await tempClient
        .from('empresas')
        .select('owner_id, tipo')
        .eq('id', empresaIdLocal)
        .maybeSingle();
      ownerId = (empresa as any)?.owner_id ?? userId;
      empresaTipoLocal = (empresa as any)?.tipo ?? empresaTipoLocal;
    }

    await sincronizarRelogioServidor();

    await salvarCredencialLocal({
      userId,
      email,
      cpf,
      senha,
      accessToken: data.session.access_token,
      refreshToken: data.session.refresh_token,
      empresaId: empresaIdLocal,
      ownerId,
    });

    await salvarPerfilCache({
      id: userId,
      nome,
      empresaId: empresaIdLocal ?? '',
      papelId,
      ownerId,
      empresaTipo: empresaTipoLocal ?? undefined,
      precisaRedefinirSenha,
    });

    setSession(data.session);
    setOffline(false);
    setEmpresaId(empresaIdLocal);
    setEmpresaTipo(empresaTipoLocal);

    try {
      await baixarLotesDoServidor(empresaIdLocal ?? '');
      await baixarFaixaConforto(empresaIdLocal ?? '');
    } catch (e) {
      console.log('Pull inicial de lotes falhou (será tentado novamente pelo auto-sync):', e);
    }

    return {};
  }

async function signInOffline(email: string, senha: string) {
  const credencial = await validarCredencialLocal(email, senha);

  if (!credencial) {
    return {
      error:
        'Não foi possível validar suas credenciais offline. Conecte-se à internet ao menos uma vez neste aparelho para habilitar o acesso sem conexão.',
    };
  }

  // Hidrata o cliente Supabase com os tokens salvos localmente.
  // Sem isso, o React acha que há sessão, mas o supabase-js continua
  // "deslogado" internamente — qualquer chamada autenticada falha,
  // mesmo depois que a internet voltar.
  try {
    await supabase.auth.setSession({
      access_token: credencial.accessToken,
      refresh_token: credencial.refreshToken,
    });
  } catch (e) {
    console.log('setSession offline falhou (token pode estar expirado):', e);
  }

  // Monta uma sessão "manual" localmente, sem chamar o servidor.
  const sessionOffline = {
    access_token: credencial.accessToken,
    refresh_token: credencial.refreshToken,
    token_type: 'bearer',
    expires_in: 3600,
    expires_at: Math.floor(Date.now() / 1000) + 3600,
    user: {
      id: credencial.userId,
      email: credencial.email,
      aud: 'authenticated',
      app_metadata: {},
      user_metadata: {},
      created_at: '',
    },
  } as unknown as Session;

  const perfilCache = await getPerfilCache(credencial.userId);
  setPrecisaRedefinirSenha(!!perfilCache?.precisaRedefinirSenha);
  setEmpresaId(perfilCache?.empresaId ?? credencial.empresaId ?? null);
  setEmpresaTipo(perfilCache?.empresaTipo ?? null);

  setSession(sessionOffline);
  setOffline(true);
  setCarregandoSessao(false);

  return {};
}


  async function signIn(email: string, senha: string) {
  const modo = await getModoSync();

  // "Sempre offline": o usuário optou explicitamente por não usar rede.
  // Vai direto para a validação local, sem gastar tempo tentando conectar.
  if (modo === 'offline') {
    return signInOffline(email, senha);
  }

  const conectado = await estaConectado();

  if (conectado) {
    try {
      return await comTimeout(signInOnline(email, senha), 15000);
    } catch (e: any) {
      // Qualquer falha de rede (timeout, ERR_INTERNET_DISCONNECTED, etc.)
      // deve tentar o caminho offline, não só o timeout específico.
      console.log('signInOnline falhou, tentando offline:', e?.message);
      const resultadoOffline = await signInOffline(email, senha);
      if (!resultadoOffline.error) return resultadoOffline;

      // Se nem offline funcionou, aí sim mostra o erro real.
      return { error: 'Sem conexão com a internet e nenhuma credencial local encontrada.' };
    }
  }

  return signInOffline(email, senha);
}




async function signInComCpf(cpf: string, senha: string) {
  const modo = await getModoSync();
  const cpfLimpo = cpf.replace(/\D/g, '');

  Alert.alert('Debug', `modo=${modo}`);

  if (modo !== 'offline') {
    const conectado = await estaConectado();

    Alert.alert('Debug', `conectado=${conectado}`);

    if (conectado) {
      try {
        const resultado = await comTimeout(buscarEmailPorCpf(cpfLimpo), 25000);

        Alert.alert('Debug', `resultado=${JSON.stringify(resultado)}`);

        if (resultado.error) return { error: resultado.error };
        if (resultado.opcoes) return { opcoes: resultado.opcoes };

        const respostaSignIn = await signIn(resultado.email!, senha);

        Alert.alert('Debug', `signIn=${JSON.stringify(respostaSignIn)}`);

        return respostaSignIn;
      } catch (e: any) {
        Alert.alert('Debug', `catch buscarEmailPorCpf: ${e?.message}`);
        console.log('buscarEmailPorCpf falhou, tentando offline:', e?.message);
        // cai para o bloco offline abaixo, independente do tipo de erro
      }
    }
  }

  const emailsSalvos = await buscarEmailLocalPorCpf(cpfLimpo);

  if (emailsSalvos.length === 0) {
    return {
      error:
        'CPF não encontrado neste aparelho. Conecte-se à internet ao menos uma vez para habilitar o acesso offline.',
    };
  }

  if (emailsSalvos.length === 1) {
    return signIn(emailsSalvos[0], senha);
  }

  return {
    opcoes: emailsSalvos.map((email) => ({ email, empresaId: '', empresaNome: email })),
  };
}






async function signUp(params: {
  senha: string;
  nomeEmpresa: string;
  nomeUsuario: string;
  cpf: string;
  emailContato?: string;
  tipoPessoa: 'Fisica' | 'Juridica';
  cpfCnpj: string;
  responsavel: string;
  telefone: string;
  paisId: number;
  estadoId: number;
  cidade: string;
  tipoEmpresa: string;
  codigoIntegracao: string | null;
  codigoParceiro: string | null;
}) {
  const cpfLimpo = params.cpf.replace(/\D/g, '');
  const empresaIdNovo = Crypto.randomUUID();
  const emailSintetico = `${cpfLimpo}-${empresaIdNovo}@gestaoavi.com`;

  const { data, error } = await supabase.functions.invoke('cadastrar-empresa', {
  body: {
    empresaId: empresaIdNovo,
    nomeEmpresa: params.nomeEmpresa,
    nomeUsuario: params.nomeUsuario,
    cpf: cpfLimpo,
    senha: params.senha,
    emailContato: params.emailContato,
    tipoPessoa: params.tipoPessoa,
    cpfCnpj: params.cpfCnpj.replace(/\D/g, ''),
    responsavel: params.responsavel,
    telefone: params.telefone,
    paisId: params.paisId,
    estadoId: params.estadoId,
    cidade: params.cidade,
    tipoEmpresa: params.tipoEmpresa,
    codigoIntegracao: params.codigoIntegracao,
    codigoParceiro: params.codigoParceiro,
  },
});

if (error) {
  // Tenta extrair a mensagem real retornada pela Edge Function
  let mensagem = 'Erro ao cadastrar. Verifique sua conexão.';

  try {
    const contexto = (error as any)?.context;
    if (contexto && typeof contexto.json === 'function') {
      const corpo = await contexto.json();
      if (corpo?.error) mensagem = corpo.error;
    }
  } catch {
    // se não conseguir ler o corpo, mantém a mensagem genérica de conexão
  }

  // Traduz erros técnicos conhecidos em mensagens amigáveis
  if (mensagem.includes('uq_empresas_cpf_cnpj')) {
    mensagem = 'Já existe uma empresa cadastrada com esse CPF ou CNPJ.';
  } else if (mensagem.includes('uq_usuarios_cpf') || mensagem.includes('cpf')) {
    mensagem = 'Já existe um usuário cadastrado com esse CPF.';
  } else if (mensagem.toLowerCase().includes('email')) {
    mensagem = 'Já existe um cadastro com esse e-mail.';
  }

  return { error: mensagem };
}

if (data?.error) {
  let mensagem = data.error;
  if (mensagem.includes('uq_empresas_cpf_cnpj')) {
    mensagem = 'Já existe uma empresa cadastrada com esse CPF ou CNPJ.';
  }
  return { error: mensagem };
}


  const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
    email: emailSintetico,
    password: params.senha,
  });

  if (loginError || !loginData.session) {
    return { error: 'Empresa criada, mas houve erro ao iniciar sessão. Tente fazer login.' };
  }

  const userId = loginData.user!.id;

  await salvarCredencialLocal({
    userId,
    email: emailSintetico,
    cpf: cpfLimpo,
    senha: params.senha,
    accessToken: loginData.session.access_token,
    refreshToken: loginData.session.refresh_token,
    empresaId: empresaIdNovo,
    ownerId: userId,
  });

  // ✅ Já sabemos o tipo da empresa (veio nos parâmetros), não precisa reconsultar
  await salvarPerfilCache({
    id: userId,
    nome: params.nomeUsuario,
    empresaId: empresaIdNovo,
    papelId: PAPEL_ID.ADMIN,
    ownerId: userId,
    empresaTipo: params.tipoEmpresa,
    precisaRedefinirSenha: false,
  });

  setSession(loginData.session);
  setOffline(false);
  setPrecisaRedefinirSenha(false);
  setEmpresaId(empresaIdNovo);
  setEmpresaTipo(params.tipoEmpresa);

  try {
    await baixarLotesDoServidor(empresaIdNovo);
    await baixarFaixaConforto(empresaIdNovo);
  } catch (e) {
    console.log('Pull inicial de lotes falhou:', e);
  }

  return {};
}


  async function atualizarSenhaPropria(novaSenha: string) {
    if (novaSenha.length < 6) {
      return { error: 'A senha deve ter no mínimo 6 caracteres.' };
    }

    const { error } = await supabase.auth.updateUser({ password: novaSenha });
    if (error) return { error: error.message };

    const userId = session?.user?.id;
    if (userId) {
      await supabase.from('perfis').update({ precisa_redefinir_senha: false }).eq('id', userId);
    }

    setPrecisaRedefinirSenha(false);
    return {};
  }

  async function signOut() {
  // scope: 'local' limpa apenas a sessão deste dispositivo/client,
 // SEM revogar o refresh_token no servidor. Isso preserva o token
 // salvo no authVault, permitindo login offline mesmo após "Sair".
 await supabase.auth.signOut({ scope: 'local' });
    setSession(null);
    setOffline(false);
    setPrecisaRedefinirSenha(false);
    setEmpresaId(null);
    setEmpresaTipo(null);
  }

  return (
    <AuthContext.Provider
      value={{
        session,
        user: session?.user ?? null,
        userId: session?.user?.id ?? null,
        offline,
        carregandoSessao,
        precisaRedefinirSenha,
        empresaId,
        empresaTipo,
        signIn,
        signInComCpf,
        signUp,
        signOut,
        atualizarSenhaPropria,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
