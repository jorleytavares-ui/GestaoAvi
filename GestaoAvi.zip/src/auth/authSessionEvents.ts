// src/auth/authSessionEvents.ts
// Emissor global para avisar o AuthContext quando qualquer parte do app
// detectar que a sessão/token está inválida (ex.: refresh token expirado).
// Isso resolve o problema de telas "presas" sem carregar nada quando o
// token expira em background, sem o usuário ser avisado ou redirecionado.

// src/auth/authSessionEvents.ts
type Listener = () => void;
const listeners: Listener[] = [];

export function onSessaoInvalida(fn: Listener) {
  listeners.push(fn);
  return () => {
    const idx = listeners.indexOf(fn);
    if (idx >= 0) listeners.splice(idx, 1);
  };
}

export function emitSessaoInvalida() {
  listeners.forEach((fn) => fn());
}

export function isErroTokenInvalido(error: any): boolean {
  if (!error) return false;
  const msg = String(error?.message ?? '').toLowerCase();
  return (
    error?.status === 401 ||
    msg.includes('refresh') ||
    msg.includes('invalid') ||
    msg.includes('expired') ||
    msg.includes('jwt')
  );
}

